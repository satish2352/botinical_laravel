<!-- Static Table Start -->

<?php $__env->startSection('content'); ?>
<style>
.fixed-table-loading {
    display: none;
}
#table thead th {
    white-space: nowrap;
}
#table thead th{
    width: 300px !important; 
    padding-right: 49px !important;
padding-left: 20px !important;
}
.custom-datatable-overright table tbody tr td {
    padding-left: 19px !important;
    padding-right: 5px !important;
    font-size: 14px;
    text-align: left;
}
</style>


<div class="data-table-area mg-tb-15">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="sparkline13-list">
                    <div class="sparkline13-hd">
                        <div class="main-sparkline13-hd">
                            <h1>All <span class="table-project-n">Business</span></h1>
                                <div class="form-group-inner login-btn-inner row">
                                 
                                <div class="col-lg-10"></div>
                            </div>
                        </div>
                    </div>

                      <?php if(Session::get('status') == 'success'): ?>
                           <div class="alert alert-success alert-success-style1">
                                <button type="button" class="close sucess-op" data-dismiss="alert" aria-label="Close">
										<span class="icon-sc-cl" aria-hidden="true">&times;</span>
									</button>
                                <i class="fa fa-check adminpro-checked-pro admin-check-pro" aria-hidden="true"></i>
                                <p><strong>Success!</strong> <?php echo e(Session::get('msg')); ?></p>
                            </div>
                             <?php endif; ?>
                            <?php if(Session::get('status') == 'error'): ?>
                              <div class="alert alert-danger alert-mg-b alert-success-style4">
                                <button type="button" class="close sucess-op" data-dismiss="alert" aria-label="Close">
										<span class="icon-sc-cl" aria-hidden="true">&times;</span>
									</button>
                                <i class="fa fa-times adminpro-danger-error admin-check-pro" aria-hidden="true"></i>
                                <p><strong>Danger!</strong> <?php echo e(Session::get('msg')); ?></p>
                            </div>
                            <?php endif; ?>

                    <div class="sparkline13-graph">
                        <div class="datatable-dashv1-list custom-datatable-overright">
                            <div id="toolbar">
                                <select class="form-control">
                                    <option value="">Export Basic</option>
                                    <option value="all">Export All</option>
                                    <option value="selected">Export Selected</option>
                                </select>
                            </div>                         
                           
                          
                            <div class="table-responsive"> 
                                <input type="hidden" class="form-control" id="business_id" name="business_id">

                                <table id="table" data-toggle="table" data-pagination="true" data-search="true"
                                    data-show-columns="true" data-show-pagination-switch="true" data-show-refresh="true"
                                    data-key-events="true" data-show-toggle="true" data-resizable="true" data-cookie="true"
                                    data-cookie-id-table="saveId" data-show-export="true" data-click-to-select="true"
                                    data-toolbar="#toolbar">
                                    
                                    <thead>
                                        <tr>
                                            <th data-field="id">Sr.No.</th>
                                            <th data-field="grn_number" data-editable="true">Title</th>
                                            <th data-field="grn_date" data-editable="true">Description</th>
                                            <th data-field="purchase_id" data-editable="true">Remark</th>
                                            <th data-field="date" data-editable="true">Sent Date</th>
                                        </tr>

                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $data_output; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e(ucwords($data->title)); ?></td>
                                            <td><?php echo e(ucwords($data->descriptions)); ?></td>
                                            <td><?php echo e(ucwords($data->remarks)); ?></td>
                                            <td><?php echo e($data->created_at); ?></td>
                                            
                                         
                                           </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\botanical_garden\resources\views/organizations/business/list/list-business.blade.php ENDPATH**/ ?>