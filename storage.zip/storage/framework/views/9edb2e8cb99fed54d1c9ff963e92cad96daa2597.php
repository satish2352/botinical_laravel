<?php $__env->startSection('content'); ?>
<section>
    <!-- bannar start -->
    <div class="banrimgs">
        <img src="<?php echo e(asset('website/assets/img/banner/contact_us.png')); ?>" alt="">
    </div>
    <div class="mobibanrimgs">
        <img src="<?php echo e(asset('website/assets/img/banner/mobcontact.png')); ?>" alt="">
    </div>
    <!-- bannar end -->

    <!--  -->
    <section>
        <div class="contbak">
            <div class="container mb-10 pt-50 pb-10">
                

        <div class="position-relative ">
            <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d30002.54703617599!2d73.6951784831116!3d19.953108539974554!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bddecafb71b21c9%3A0xa6dab4828bb274df!2sMIDC%20Ambad%2C%20Nashik%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1707914483331!5m2!1sen!2sin"
                width="100%" id="ifrm" style="border:0;" allowfullscreen="" loading="lazy"
                referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>

        <div class="addrescard addresscenter  pt-20">
            <div class="card" style="width: 25rem;">
                <h4 class="card-header card-info2 text-center text-white">
                    Address
                </h4>
                <div class="card-body text-justify p-4">
                    <ul class="clrtext">
                        <li><span class="f-600">Plant No. 1</span> W-127 (A),</li>
                        <br>
                        <li><span class="f-600">Plant No. 2</span> - W-118 (A) MIDC Ambad Nashik - 422010 ,</li>
                        <br>
                        <li><span class="f-600">Plant No. 3</span> - GAT NO679/2/1 , Kurli Alandi Road ,Chankan , Tal
                            khed Dist. Pune - 410501,</li>
                        <br>
                        <li><span class="f-600">Plant No. 4</span> - GF Plot No - 913 Shreeji Engg, GIDC , Halol ,
                            Panchamahal Gujarat - 389350</li>


                    </ul>
                </div>
            </div>
        </div>
        </div>

        <div class="contcatcontainer ">
            <div class="card shadow-1">

                <div class="row">
                    <div class="col-lg-4 col-2 col-sm-4">
                        <img src="<?php echo e(asset('website/assets/img/contact/callimg1.png')); ?>" alt="">
                    </div>
                    <div class="col-lg-8 col-4 col-sm-8 contnom mt-60">
                        <div class="row">
                            <div class="col-lg-3 col-md-3 col-sm-3">
                                <h5 class="f-700 clrtext">Contact</h5>
                            </div>
                            <ul class="d-flex col-lg-9 col-md-9 col-sm-9">
                                <li><a href="tel:+91 7028082176" class="clrtext  f-600">7028082176</a>
                                </li>
                                <li><a href="tel: +91 0253 - 2383517" class="clrtext ml-20 f-600">0253-2383517</a>
                                </li>
                            </ul>


                        </div>
                        <div class="row social-links mb-20 ">
                            <div class="col-lg-5 col-md-5 mt-0 py-3">
                                <h5 class="f-700 clrtext">Follow us on</h5>

                            </div>
                            <div class="col-lg-7 col-md-7 social-links social-links1 ">
                                <ul class="social-icons sociicon">
                                    <li>
                                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                                    </li>

                                    <li>
                                        <a href="#"><i class="fab fa-instagram"></i></a>
                                    </li>
                                    <li class="email">
                                        <a href="#"><i class="fa-regular fa-envelope "></i></a>
                                    </li>
                                </ul>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
        </div>
        </div>
    </section>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shreerang-main_bk\resources\views/website/pages/contact.blade.php ENDPATH**/ ?>