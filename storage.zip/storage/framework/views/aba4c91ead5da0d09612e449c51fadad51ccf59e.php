
<?php $__env->startSection('content'); ?>
<section>
      <!-- bannar start -->
      <div class="banrimgs">
        <img src="<?php echo e(asset('website/assets/img/banner/home_bnr.png')); ?>" alt="">
    </div>
    <div class="mobibanrimgs">
    <img src="<?php echo e(asset('website/assets/img/banner/homepage.png')); ?>" alt="">
    </div>
    <!-- bannar end -->

     <!-- Slider start -->
     

        
        <!-- <div class="slide-social-outer transform-v-center z-5">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 w-100">
                        <div class="slide-social d-none d-lg-block">
                            <ul class="social-icons">
                                <li>
                                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                                </li>
                                <li>
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                </li>
                                <li>
                                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                </li>
                                <li>
                                    <a href="#"><i class="fab fa-google-plus-g"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->
        
    <!-- Slider end -->

     <!-- title start -->
     <section class="callback-area" data-overlay="9">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="fancy-head text-center relative z-5 m-3 pt-10 wow fadeInDown">
                        <h1 class="white fs1">Product</h1>
                    </div>
                </div>
            </div>
            
        </div>
    </section>
    <!-- title end -->

       <!-- products  start -->
<div class="">
     <section class="team-area bg-blue-op-11 pt-40 pb-40">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-6 mb-20 p-4">
                    <div class="team-2-each card relative border shadow-3">
                    <div class="product_img text-center">
                        <h4 class="f-800 pt-4 fs2 clrtext">TAILOR</h4>
                        <a ><img src="<?php echo e(asset('website/assets/img/products/Ellipse 7.png')); ?>" id="prodimgss" alt=""></a>
                    </div>
                        <div class="team-hover-div procard text-center transition-3">
                            
                            <!-- <p class="green mb-0">Co Founder</p> -->
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 mb-20 p-4">
                    <div class="team-2-each card relative border shadow-3">
                        <div class="product_img text-center">
                            <h4 class="f-800 pt-4 fs2 clrtext">PLATFORM</h4>
                            <a><img src="<?php echo e(asset('website/assets/img/products/Ellipse 6.png')); ?>" id="prodimgss" alt=""></a>
                        </div>
                        <div class="team-hover-div procard text-center transition-4">
                            
                            <!-- <p class="green mb-0">Marketing Manager</p> -->
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 mb-20 p-4">
                    <div class="team-2-each card relative border shadow-3">
                    <div class="product_img text-center">
                        <h4 class="f-800 pt-4 fs2 clrtext">PLATS</h4>
                        <a><img src="<?php echo e(asset('website/assets/img/products/Ellipse 5.png')); ?>" id="prodimgss" alt=""></a>
                    </div>
                        <div class="team-hover-div procard text-center transition-4">
                            
                            <!-- <p class="green mb-0">Web Designer</p> -->
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 mb-20 p-4">
                    <div class="team-2-each card relative border shadow-3">
                    <div class="product_img text-center">
                        <h4 class="f-800 pt-4 fs2 clrtext">PLATFORM</h4>
                        <a><img src="<?php echo e(asset('website/assets/img/products/Ellipse 6.png')); ?>" id="prodimgss" alt=""></a>
                    </div>
                        <div class="team-hover-div procard text-center transition-4">
                            
                            <!-- <p class="green mb-0">Finance Manager</p> -->
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 mb-20 p-4">
                    <div class="team-2-each card relative border shadow-3">
                    <div class="product_img text-center">
                        <h4 class="f-800 pt-4 fs2 clrtext">TAILOR</h4>
                        <a><img src="<?php echo e(asset('website/assets/img/products/Ellipse 7.png')); ?>" id="prodimgss" alt=""></a>
                    </div>
                        <div class="team-hover-div procard text-center transition-4">
                            
                            <!-- <p class="green mb-0">Web Designer</p> -->
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 mb-20 p-4">
                    <div class="team-2-each card relative border shadow-3">
                    <div class="product_img text-center">
                        <h4 class="f-800 pt-4 fs2 clrtext">PLATS</h4>
                        <a><img src="<?php echo e(asset('website/assets/img/products/Ellipse 5.png')); ?>" id="prodimgss" alt=""></a>
                    </div>
                        <div class="team-hover-div procard text-center transition-4">
                            
                            <!-- <p class="green mb-0">Web Designer</p> -->
                        </div>
                    </div>
                </div>
                                
            </div>
            <div class="row text-center pt-10">
                    <div class="col-lg-9 col-md-6"></div>
                    <div class="col-lg-3 col-md-6">

                        <a href="<?php echo e(url('/product')); ?>" class="btn btn-round">View all products</a>
                    </div>
                </div>
        </div>
    </section>
</div>
   
    <!-- Products end -->


        <!-- services start -->
        <section class="servicebk" data-overlay="9" >
            <div class="container-fluid testmo ">
                <div class="row ">
                    <div class="col-xl-12">
                        <div class="fancy-head text-center relative z-5 mb-30  wow fadeInDown">
                            <h1 class="white f-800 fs1 mt-60 ">Service</h1>
                        </div>
                    </div>
                </div>
                <div class="row align-items-center mb-10 mt-4">
                    
                    <div class="col-lg-4 col-xx-3 z-5 text-center text-lg-left wow fadeIn">
                        <div class="exp-cta pr-50 pr-lg-00 servicetext">
                            <h2 class="white text-center d-flex justify-content-center hptext1  f-700 mb-10">
                                <span class="fontsize30 f-900 fs-1   mr-20">01</span>
                                WOODWORKING
                                <span class="green"></span>
                            </h2>
                            <p class="white1 pfonts mb-55 mb-md-30 pr-70 pl-70 mt-20  f-500 bigfont hptext text-justify">Lorem, ipsum dolor sit amet consectetur adipisicing elit. stiae exercitationem debitis enim quaerat.</p>
                            <!-- <a href="contact-us.html" class="btn btn-square">Contact us<i class="fas fa-long-arrow-alt-right ml-20"></i></a> -->
                        </div>
                    </div>
                    <div class="col-lg-4 z-5 col-xxl-3 text-center text-lg-left wow fadeIn">
                        <div class="exp-cta pr-50 pr-lg-00 servicetext">
                            <h2 class="white f-700 text-center d-flex  justify-content-center hptext1  mb-10">
                                <span class="fontsize30 f-900  fs-1 mr-20">02</span>
                                METALWORKING
    
                            </h2>
                            <p class="white1 pfonts mb-55 mb-md-30 pr-70 pl-70 mt-20  f-500 bigfont hptext text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. stiae exercitationem debitis enim quaerat.</p>
                            <!-- <a href="contact-us.html" class="btn btn-square">Contact us<i class="fas fa-long-arrow-alt-right ml-20"></i></a> -->
                        </div>
                    </div>
                    <div class="col-lg-4 col-xxl-3  z-5 text-center text-lg-left wow fadeIn">
                        <div class="exp-cta pr-50 pr-lg-00 servicetext">
                            <h2 class="white text-center d-flex justify-content-center hptext1 f-700 mb-10">
                                <span class="fontsize30 f-900  fs-1 mr-20">03</span>
                                WOODWORKING
                                <span class="green"></span>
                            </h2>
                            <p class="white1 pfonts mb-55 mb-md-30 pr-70 pl-70 mt-20 hptext f-500 bigfont   text-justify">Lorem, ipsum dolor sit amet consectetur adipisicing elit. stiae exercitationem debitis enim quaerat.</p>
                            <!-- <a href="contact-us.html" class="btn btn-square">Contact us<i class="fas fa-long-arrow-alt-right ml-20"></i></a> -->
                        </div>
                    </div>
                    </div>
                    <div class="row ">
                    <div class="col-lg-11 z-5 text-center text-lg-left wow fadeIn">
                        <div class="servbtn mb-90 mb-md-20 d-flex justify-content-end ">
                            <a href="<?php echo e(url('/services')); ?>" class="btn btn-round  justify-content-end">View all services</a>
    
                        </div>
                    </div>
                   
                    </div>
           
            </div>
    </section>
    <!-- services end -->

      <!-- How we work  -->
      
      <section>
        <div class="container-fluid testmo paddiall4 bg-insta mb-3 ">
            <div class="row pb-50 pb-md-20 pb-sm-20">
                <div class="col-xl-4 pl-60 pr-60 mt-30">
                    <div class="item">
                        <h1 class="f-800 clrtext position-absolute"><span class="btn btn-round1 pd00"><h1 class="white fs1 f-800">01 </h1></span> Request</h1>
                        <img src="<?php echo e(asset('website/assets/img/icons/1.png')); ?>" alt="">
                        <h6 class="clrtext text-justify align-content-center  fs-18 mrtp pt-3">Lorem ipsum dolor sit Provident nam illum, maxime ipsum nostrum amet, consectetur adipisicing  aut unde officiis eveniet</h6>
                    </div>
                </div>
                
                <div class="col-xl-4 pl-60 pr-60 mt-30">
                    <div class="item">
                    <h1 class="f-800 clrtext position-absolute"><span class="btn btn-round1 pd00"><h1 class="white fs1 f-800">02 </h1></span> Develop</h1>
                        <img src="<?php echo e(asset('website/assets/img/icons/2.png')); ?>"  alt="">
                        <h6 class="clrtext text-justify fs-18 mrtp pt-3">Lorem ipsum dolor sit Provident nam illum, maxime ipsum nostrum amet, consectetur adipisicing  aut unde officiis eveniet</h6>
                    </div>
                </div>
                <div class="col-xl-4 pl-60 pr-60 mt-30">
                    <div class="item">
                    <h1 class="f-800 clrtext position-absolute"><span class="btn btn-round1 pd00"><h1 class="white fs1 f-800">03 </h1></span> Install</h1>
                        <img src="<?php echo e(asset('website/assets/img/icons/3.png')); ?>"  alt="">
                        <h6 class="clrtext text-justify fs-18 mrtp pt-3">Lorem ipsum dolor sit Provident nam illum, maxime ipsum nostrum amet, consectetur adipisicing  aut unde officiis eveniet</h6>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- end  How we work-->

     <!-- Testimonial area start -->
     <section class="testimonials-2 reviw">
        <div class="container-fluid paddiall  paddiall1 testmo1">
            <div class="row align-items-center mb-30">
                <div class="col-lg-12 col-md-12 text-center text-lg-center">
                    <div class="fancy-head left-al wow fadeInLeft">
                        
                        <h1 class="clrtext fs1">Testimonial</h1>
                    </div>
                </div>
                
                <!-- <div class="col-12">
                    <div class="hr-2 bg-blue opacity-1 mt-45"></div> 
                </div> -->
            </div>
            <div class="row marginleft75">
                <div class="col-xl-12">
                    <div class="owl-carousel owl-theme testimonial-2-slide  wow fadeIn">
                        <div class="">
                            <div class="each-quote-2 pl-20 pr-sm-00 card cardwidth" style="height: 350px; border-top:15px solid #243772; background:#e2feff">
                                <!-- <ul class="stars-rate mb-5" data-starsactive="5">
                                    <li class="text-md-left text-center">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                    </li>
                                </ul> -->
                                <h4 class="f-700 mb-20 pt-20  icn"  id="pr"><i class="fa-solid fa-quote-left  "></i></h4>
                                <p class="mb-35 pb-10 clrtext text-justify pr-10 lnh">"Shreerag Engineering's trolleys and rollers have transformed our warehouse operations. Their products' durability and efficiency exceeded our expectations, making them our top choice for material handling solutions."</p>
                                <div class="client-2-img d-flex  fixed-bottom1 justify-content-md-start justify-content-start">
                                    <div class="img-div   pb-20">
                                        <div class="client-image">
                                            <img src="<?php echo e(asset('website/assets/img/team/team5b.png')); ?>" class=" rounded-circle" alt="">
                                        </div>
                                    </div>
                                    <div class="client-text-2 mb-30 pl-20">
                                        <h6 class="client-name green fs-17 f-700 clrtext">Mr. Sachin Katkade </h6>
                                        <p class="mb-0 fs-13 f-400 clrtext mb-30">Technical Expert</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="">
                            <div class="each-quote-2 pl-20 pr-sm-00 card cardwidth" style="height: 350px; border-top:15px solid #243772; background:#e2feff">
                                <!-- <ul class="stars-rate mb-5" data-starsactive="5">
                                    <li class="text-md-left text-center">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                    </li>
                                </ul> -->

                                <h4 class="f-700 mb-20 pt-20 icn" id="pr"><i class="fa-solid fa-quote-left"></i></h4>
                                <p class="mb-35 pb-10 clrtext text-justify pr-10 lnh">"Their conveyors elevated our production efficiency. Their craftsmanship and design expertise make them the go-to partner for reliable material handling solutions."</p>
                                <div class="client-2-img d-flex  fixed-bottom1  justify-content-md-start justify-content-start">
                                    <div class="img-div  pb-20 ">
                                        <div class="client-image">
                                            <img src="<?php echo e(asset('website/assets/img/team/team3b.png')); ?>" class=" rounded-circle" alt="">
                                        </div>
                                    </div>
                                    <div class="client-text-2 mb-30  ">
                                        <h6 class="client-name green fs-17 f-700 clrtext">Dhananjay Makhwani</h6>
                                        <p class="mb-0 fs-13 f-400 clrtext mb-30">Co- worker</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class=" ">
                            <div class="each-quote-2 pl-20 pr-sm-00 card cardwidth" style="height: 350px; border-top:15px solid #243772; background:#e2feff">
                                <!-- <ul class="stars-rate mb-5" data-starsactive="5">
                                    <li class="text-md-left text-center">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                    </li>
                                </ul> -->

                                <h4 class="f-700 mb-20 pt-20 icn" id="pr"><i class="fa-solid fa-quote-left"></i></h4>
                                <p class="mb-35 pb-10 clrtext text-justify pr-10 lnh">"Shreerag’s metallic pallets have been a valuable asset to our inventory management. The precision in their manufacturing process and attention to detail are evident in the quality of their products."</p>
                                <div class="client-2-img d-flex fixed-bottom1  justify-content-md-start justify-content-start">
                                    <div class="img-div  pb-20 ">
                                        <div class="client-image">
                                            <img src="<?php echo e(asset('website/assets/img/team/team1b.png')); ?>" class=" rounded-circle" alt="">
                                        </div>
                                    </div>
                                    <div class="client-text-2 mb-30 pl-5 ">
                                        <h6 class="client-name green fs-17 f-700 clrtext">Abhaykumar Sansare</h6>
                                        <p class="mb-0 fs-13 f-400 clrtext">Branch Manager</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class=" ">
                            <div class="each-quote-2 pl-20 pr-sm-00 card cardwidth" style="height: 350px; border-top:15px solid #243772; background:#e2feff">
                                <!-- <ul class="stars-rate mb-5" data-starsactive="5">
                                    <li class="text-md-left text-center">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                    </li>
                                </ul> --> 
                                <h4 class="f-700 mb-20 pt-20 icn" id="pr"><i class="fa-solid fa-quote-left"></i></h4>
                                <p class="mb-35 pb-10 clrtext text-justify pr-10 lnh">"Shreerag Engineering's custom trolleys have streamlined our operations. Their commitment to delivering innovative solutions tailored to our industry's needs sets them apart as a trusted partner."</p>
                                <div class="client-2-img d-flex fixed-bottom1  justify-content-md-start justify-content-start">
                                    <div class="img-div pb-20">
                                        <div class="client-image">
                                            <img src="<?php echo e(asset('website/assets/img/team/team3b.png')); ?>" class=" rounded-circle" alt="">
                                        </div>
                                    </div>
                                    <div class="client-text-2 mb-30 pl-20">
                                        <h6 class="client-name green fs-17 f-700 clrtext">Prakash Ingale</h6>
                                        <p class="mb-0 fs-13 f-400 clrtext">Production Manager</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class=" ">
                            <div class="each-quote-2 pl-20 pr-sm-00 card cardwidth" style="height: 350px; border-top:15px solid #243772; background:#e2feff">
                                <!-- <ul class="stars-rate mb-5" data-starsactive="5">
                                    <li class="text-md-left text-center">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                    </li>
                                </ul> -->            
                                <h4 class="f-700 mb-20 pt-20 icn" id="pr"><i class="fa-solid fa-quote-left"></i></h4>
                                <p class="mb-35 pb-10 clrtext text-justify pr-10 lnh">"The rollers are robust, durable, and remarkably efficient. Their professionalism make them our trusted supplier for all material handling equipment."
                                </p>
                                <div class="client-2-img d-flex fixed-bottom1 justify-content-md-start justify-content-start">
                                    <div class="img-div  pb-20">
                                        <div class="client-image">
                                            <img src="<?php echo e(asset('website/assets/img/team/team2b.png')); ?>" class=" rounded-circle" alt="">
                                        </div>
                                    </div>
                                    <div class="client-text-2  mb-30 pl-20">
                                        <h6 class="client-name green fs-17 f-700 clrtext">Vikas Sawant</h6>
                                        <p class="mb-0 fs-13 f-400 clrtext">Expert Advisor</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class=" ">
                            <div class="each-quote-2 pl-20 pr-sm-00 card cardwidth" style="height: 350px; border-top:15px solid #243772; background:#e2feff;">
                                <!-- <ul class="stars-rate mb-5" data-starsactive="5">
                                    <li class="text-md-left text-center">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                    </li>
                                </ul> -->
                                
                                <h4 class="f-700 mb-20 pt-20 icn" id="pr"><i class="fa-solid fa-quote-left"></i></h4>
                                <p class="mb-35 pb-10 clrtext text-justify pr-10 lnh">"Shreerag Engineering's conveyors have significantly improved our production line. Their commitment to delivering comprehensive solutions tailored to our business needs makes them a reliable partner."
                                </p>
                                <div class="client-2-img d-flex fixed-bottom1 justify-content-md-start justify-content-start">
                                    <div class="img-div  pb-20">
                                        <div class="client-image">
                                            <img src="<?php echo e(asset('website/assets/img/team/team2b.png')); ?>" class=" rounded-circle" alt="">
                                        </div>
                                    </div>
                                    <div class="client-text-2  mb-30 pl-20">
                                        <h6 class="client-name green fs-17 f-700 clrtext">Shubham Pawar</h6>
                                        <p class="mb-0 fs-13 f-400 clrtext">Safety Manager</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Testimonial area end -->
    
    <!-- contact -->
    <section>
        <div class="container-fluid testmo text-center pt-50 pb-50 indexlastimg">
           
             <!-- bannar start -->
            <div class="banrimgs">
             <div class="   ">  <img src="<?php echo e(asset('website/assets/img/banner/contactnew.png')); ?>" alt="">
              </div>             
             </div> 
            <div class="mobibanrimgs">
            <div class=" ">  <img src="<?php echo e(asset('website/assets/img/banner/contact.png')); ?>" alt="">
              </div>
            </div> 
        <!-- bannar end -->

        </div>
    </section>

<div class="paddiall2"></div>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\botanical_garden\resources\views/website/pages/index.blade.php ENDPATH**/ ?>