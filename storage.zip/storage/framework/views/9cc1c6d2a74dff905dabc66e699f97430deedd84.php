</div>
<div class="footer-copyright-area navbar-fixed-bottom">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="footer-copy-right">
                    <p>Copyright &copy; <?php echo e(date('Y')); ?> <a href="https://www.sumagoinfotech.com"
                            target="_blank"> Made with Passion by Sumago Infotech.</a></p>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="<?php echo e(asset('js/vendor/jquery-1.11.3.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery-price-slider.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.meanmenu.js')); ?>"></script>
<script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.sticky.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.scrollUp.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/scrollbar/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/scrollbar/mCustomScrollbar-active.js')); ?>"></script>
<script src="<?php echo e(asset('js/metisMenu/metisMenu.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/metisMenu/metisMenu-active.js')); ?>"></script>
<script src="<?php echo e(asset('js/morrisjs/raphael-min.js')); ?>"></script>
<script src="<?php echo e(asset('js/morrisjs/morris.js')); ?>"></script>
<script src="<?php echo e(asset('js/morrisjs/morris-active.js')); ?>"></script>
<script src="<?php echo e(asset('js/sparkline/jquery.sparkline.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/sparkline/jquery.charts-sparkline.js')); ?>"></script>
<script src="<?php echo e(asset('js/calendar/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/calendar/fullcalendar.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/calendar/fullcalendar-active.js')); ?>"></script>
<script src="<?php echo e(asset('js/plugins.js')); ?>"></script>
<script src="<?php echo e(asset('js/main.js')); ?>"></script>
<script src="<?php echo e(asset('js/data-table/bootstrap-table.js')); ?>"></script>
<script src="<?php echo e(asset('js/data-table/tableExport.js')); ?>"></script>
<script src="<?php echo e(asset('js/data-table/data-table-active.js')); ?>"></script>
<script src="<?php echo e(asset('js/data-table/bootstrap-table-editable.js')); ?>"></script>
<script src="<?php echo e(asset('js/data-table/bootstrap-editable.js')); ?>"></script>
<script src="<?php echo e(asset('js/data-table/bootstrap-table-resizable.js')); ?>"></script>
<script src="<?php echo e(asset('js/data-table/colResizable-1.5.source.js')); ?>"></script>
<script src="<?php echo e(asset('js/data-table/bootstrap-table-export.js')); ?>"></script>
<script src="<?php echo e(asset('js/editable/jquery.mockjax.js')); ?>"></script>
<script src="<?php echo e(asset('js/editable/mock-active.js')); ?>"></script>
<script src="<?php echo e(asset('js/editable/select2.js')); ?>"></script>
<script src="<?php echo e(asset('js/editable/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/editable/bootstrap-datetimepicker.js')); ?>"></script>
<script src="<?php echo e(asset('js/editable/bootstrap-editable.js')); ?>"></script>
<script src="<?php echo e(asset('js/editable/xediable-active.js')); ?>"></script>
<script src="<?php echo e(asset('js/chart/jquery.peity.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/peity/peity-active.js')); ?>"></script>
<script src="<?php echo e(asset('js/tab.js')); ?>"></script>
<link rel="stylesheet" href="<?php echo e(asset('https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css')); ?>">
<script src="<?php echo e(asset('https://cdn.jsdelivr.net/npm/flatpickr')); ?>"></script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\botanical_garden\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>