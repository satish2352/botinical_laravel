<?php $__env->startSection('content'); ?>
<section>

    <!-- bannar start -->
    <div class="banrimgs">
        <img src="<?php echo e(asset('website/assets/img/banner/SERVICES.png')); ?>" alt="">
    </div>
    <div class="mobibanrimgs">
        <img src="<?php echo e(asset('website/assets/img/banner/mobservice.png')); ?>" alt="">
    </div>
    <!-- bannar end -->


    <!-- imgs -->
    <section class="paddiall2 mb-50">
        <div class="" data-overlay="9">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="fancy-head text-center relative z-5 mt-30 mb-40 wow fadeInDown">
                            <h1 class="clrtext fs5">Manufacturing <span class="green fs6">Of</span></h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="bakimgbnr">
            <div class="container-fluid serv pt-5 pb-30">

                <div class="row">

                    <div class="col-lg-3 manuimg1 text-center">
                        <img src="<?php echo e(asset('website/assets/img/service/trolly.png')); ?>" id="sevimg" alt="">
                        <div class="p-3">
                            <h2 class="f-700 clrtext">Trolley</h2>
                        </div>
                    </div>
                    <div class="col-lg-3 manuimg2 text-center">
                        <img src="<?php echo e(asset('website/assets/img/service/roller.png')); ?>" id="sevimg" alt="">
                        <div class="p-3">
                            <h2 class="f-700 clrtext">Rollers</h2>
                        </div>
                    </div>
                    <div class="col-lg-3 manuimg3 text-center">
                        <img src="<?php echo e(asset('website/assets/img/service/conveyer.png')); ?>" id="sevimg" alt="">
                        <div class="p-3">
                            <h2 class="f-700 clrtext">Conveyers</h2>
                        </div>
                    </div>
                    <div class="col-lg-3 manuimg4 text-center">
                        <img src="<?php echo e(asset('website/assets/img/service/metalic_pallet.png')); ?>" id="sevimg" alt="">
                        <div class="p-3">
                            <h2 class="f-700 clrtext">Metalic Pallet</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- end imgs -->
    <!-- services start -->
    <section class="servicebnnr paddiall">
        <div class="container-fluid testmo">
            
            <div class="row align-items-md-center  paddiall4">
                <div class="col-lg-4 z-5 text-center text-lg-left wow fadeIn">
                    <div class="exp-cta pr-50 pr-lg-00 servicetext">
                        <h2 class="white text-center d-flex justify-content-center f-700 ">
                            <span class="fontsize30 fs-1 mr-20">01</span>
                            WOODWORKING
                            <span class="green"></span>
                        </h2>
                        <p
                            class="white1 pfonts mb-55 mb-md-30  mt-30  f-500 pr-md-00  bigfont text-justify">
                            Lorem, ipsum dolor sit amet consectetur adipisicing elit. stiae exercitationem debitis enim
                            quaerat.</p>
                        <!-- <a href="contact-us.html" class="btn btn-square">Contact us<i class="fas fa-long-arrow-alt-right ml-20"></i></a> -->
                    </div>
                </div>
                <div class="col-lg-4 z-5 text-center text-lg-left wow fadeIn ">
                    <div class="exp-cta pr-50 pr-lg-00 servicetext">
                        <h2 class="white f-700 text-center d-flex justify-content-center f-700 ">
                            <span class="fontsize30 fs-1 mr-20">02</span>
                            METALWORKING

                        </h2>
                        <p
                            class="white1 pfonts mb-55 mb-md-30 mt-30 xxl-pr f-500 pr-md-00 bigfont text-justify">
                            Lorem, ipsum dolor sit amet consectetur adipisicing elit. stiae exercitationem debitis enim
                            quaerat</p>
                        <!-- <a href="contact-us.html" class="btn btn-square">Contact us<i class="fas fa-long-arrow-alt-right ml-20"></i></a> -->
                    </div>
                </div>
                <div class="col-lg-4 z-5 text-center text-lg-left wow fadeIn">
                    <div class="exp-cta pr-50 pr-lg-00 servicetext ">
                        <h2 class="white f-700 text-center d-flex justify-content-center f-700 ">
                            <span class="fontsize30 fs-1 mr-20">03</span>
                            WOODWORKING
                            <span class="green"></span>
                        </h2>
                        <p
                            class="white1 pfonts mb-55 mb-md-15 mt-30 f-500 pr-md-00 bigfont text-justify">
                            Lorem, ipsum dolor sit amet consectetur adipisicing elit. stiae exercitationem debitis enim
                            quaerat.</p>
                        <!-- <a href="contact-us.html" class="btn btn-square">Contact us<i class="fas fa-long-arrow-alt-right ml-20"></i></a> -->
                    </div>
                </div>


            </div>


        </div>
    </section>
    <!-- services end -->


    <!-- material handling  -->

    <section class="paddiall2">
        

        <div data-overlay="9">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="fancy-head text-center relative z-5 wow fadeInDown ">
                            <h1 class="fs6 mthtext">Material Handling <span class="green">Equipment For</span></h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="container-fluid text-center col-12 banrimgs imgnag  ">

                <img src="<?php echo e(asset('website/assets/img/banner/material.png')); ?>" alt="">

            </div>

            <div class="container-fluid text-center mobibanrimgs mhmi ">


                <img src="<?php echo e(asset('website/assets/img/banner/Materialnew2.jpg')); ?>" alt="">
            </div>

            

        </div>
        
    </section>
    <!-- end material handling -->

    <!-- img -->
    <section>
        <div class="">
            <!-- bannar start -->
            <div class="banrimgs">
                <img src="<?php echo e(asset('website/assets/img/banner/HOME_PAGE3old.png')); ?>" alt="">
            </div>
            <div class="mobibanrimgs">
                <img src="<?php echo e(asset('website/assets/img/banner/mobconnectold.jpg')); ?>" alt="">
            </div>
            <!-- bannar end -->
        </div>
    </section>
    <!-- img -->

    <!-- cards -->


    <section class="cardbkclr paddiall2 ">
        <div class="container-fluid testmo1 paddiall">
            <div class="row">
                <div class="col-lg-12"></div>
                <div class="col-lg-6 col-md-12 p-2 exp">
                    <div class="card border-0 bkcl">
                        <img src="<?php echo e(asset('website/assets/img/service/caster.png')); ?>" class="card-img-top" alt="...">
                        <div class="card-body  text-center card-info">
                            <h1 class="white fs2 f-600"> Caster wheels </h1>

                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 p-2 exp ">
                    <div class="card border-0 bkcl">
                        <img src="<?php echo e(asset('website/assets/img/service/movement.png')); ?>" class="card-img-top" alt="...">
                        <div class="card-body text-center  card-info">
                            <h1 class="white fs2 f-600 line-ht pptt"> Movement Trollies </h1>

                        </div>

                    </div>
                </div>
            </div>

            <div class="row">


                <div class="col-lg-6 col-md-12 p-2 exp ">
                    <div class="card border-0 bkcl">
                        <img src="<?php echo e(asset('website/assets/img/service/fabrication.png')); ?>" class="card-img-top"
                            alt="...">
                        <div class="card-body text-center card-info1">
                            <h1 class="white fs2 f-600 line-ht ptb "> Challenging Fabrication Works </h1>

                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 p-2 exp ">
                    <div class="card border-0 bkcl ">
                        <img src="<?php echo e(asset('website/assets/img/service/presshop.png')); ?>" class="card-img-top" alt="...">
                        <div class="card-body text-center  card-info1">
                            <h1 class="white fs2 f-600 line-ht  topbottom   "> Press Shop Works </h1>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- cards -->
</section>
<div class="paddiall2"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shreerang-main_bk\resources\views/website/pages/services.blade.php ENDPATH**/ ?>