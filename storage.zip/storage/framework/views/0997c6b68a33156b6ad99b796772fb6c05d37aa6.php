<div class="left-sidebar-pro">
    <nav id="sidebar" class="">
        <div class="sidebar-header">
            <a href="index.html"><img class="main-logo" src="<?php echo e(asset('website/assets/img/logo/LANSCAPE LOG.png')); ?>"
                    alt=""></a>
            <strong><img src="<?php echo e(asset('img/logo/logo.png')); ?>" alt=""></strong>
        </div>
        <div class="left-custom-menu-adp-wrap comment-scrollbar">
            <nav class="sidebar-nav left-sidebar-menu-pro">

                <ul class="metismenu" id="menu1">
                    <?php if(session()->get('role_id') == config('constants.ROLE_ID.SUPER')): ?>
                        <li>
                            <a class="has-arrow" href="<?php echo e(route('list-organizations')); ?>" aria-expanded="false"><i
                                    class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">Organizations</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Inbox" href="<?php echo e(route('list-organizations')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">List Organizations</span></a></li>
                                <li><a title="Inbox" href="<?php echo e(route('organizations-list-employees')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">List Employees</span></a>
                                </li>
                                <li><a title="Inbox" href="<?php echo e(route('list-departments')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">List Departments</span></a>
                                </li>
                                <li><a title="Inbox" href="<?php echo e(route('list-roles')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">List Roles</span></a></li>
                            </ul>
                        </li>

                        <!-- <li class="">
                            <a class="has-arrow" href="index.html">
                                <i class="fa big-icon fa-home icon-wrap"></i>
                                <span class="mini-click-non">Basic Product </span>
                            </a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Inbox" href="<?php echo e(route('list-products')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">List Products</span></a></li>
                            </ul>
                        </li> -->
                        <!-- <li>
                            <a class="has-arrow" href="<?php echo e(route('organizations-list-employees')); ?>"
                                aria-expanded="false"><i class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">Employees</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Inbox" href="<?php echo e(route('organizations-list-employees')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">Add Employees</span></a></li>
                            </ul>
                        </li> -->

                        <!-- <li>
                            <a class="has-arrow" href="<?php echo e(route('organizations-list-employees')); ?>"
                                aria-expanded="false"><i class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">Employees</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Inbox" href="<?php echo e(route('organizations-list-employees')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">Add Employees</span></a></li>
                            </ul>
                        </li> -->
                    <?php endif; ?>

                    <?php if(session()->get('role_id') == config('constants.ROLE_ID.HIGHER_AUTHORITY')): ?>
                        <li>
                            <a class="has-arrow" href="<?php echo e(route('organizations-list-employees')); ?>"
                                aria-expanded="false"><i class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">Employees</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Inbox" href="<?php echo e(route('organizations-list-employees')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">Add Employees</span></a></li>
                            </ul>
                        </li>

                        <li>
                            <a class="has-arrow" href="<?php echo e(route('list-business')); ?>" aria-expanded="false"><i
                                    class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">Business</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Inbox" href="<?php echo e(route('list-business')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">Business List</span></a></li>
                            </ul>
                        </li>

                        <li>
                            <a class="has-arrow" href="<?php echo e(route('list-forwarded-to-design')); ?>"
                                aria-expanded="false"><i class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">List Business Sent For Design</span></a>
                        </li>

                        <li>
                            <a class="has-arrow" href="<?php echo e(route('list-design-upload')); ?>" aria-expanded="false"><i
                                    class="fa big-icon fa-envelope icon-wrap"></i> <span class="mini-click-non">List
                                    Design Received <br> For Production</span></a>
                        </li>

                        <li>
                            <a class="has-arrow" href="<?php echo e(route('list-design-correction')); ?>"
                                aria-expanded="false"><i class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">List Design Received <br> For Design Correction</span></a>
                        </li>
                    <?php endif; ?>
                    <?php if(session()->get('role_id') == config('constants.ROLE_ID.PURCHASE')): ?>
                        
                        <li>
                            <a class="has-arrow" href="<?php echo e(route('list-purchase')); ?>" aria-expanded="false"><i
                                    class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">Purchase
                                    Orders</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Inbox" href="<?php echo e(route('list-purchase')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">List Purchase Orders</span></a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="<?php echo e(route('list-vendor')); ?>" aria-expanded="false"><i
                                    class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">Vendor</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Inbox" href="<?php echo e(route('list-vendor')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">Vendor List</span></a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if(session()->get('role_id') == config('constants.ROLE_ID.DESIGNER')): ?>
                        
                        <li>
                            <a class="has-arrow" href="<?php echo e(route('list-new-requirements-received-for-design')); ?>"
                                aria-expanded="false"><i class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">List New Requirements <br> Received For Design</span></a>
                        </li>
                        <li>
                            <a class="has-arrow" href="<?php echo e(route('list-design-upload')); ?>" aria-expanded="false"><i
                                    class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">Designs Sent To Porduction</span></a>
                        </li>

                        <li>
                            <a class="has-arrow" href="<?php echo e(route('list-reject-design-from-prod')); ?>"
                                aria-expanded="false"><i class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">Rejected Design List</span></a>
                        </li>


                        
                    <?php endif; ?>
                    <?php if(session()->get('role_id') == config('constants.ROLE_ID.PRODUCTION')): ?>
                        <li>
                            <a class="has-arrow" href="<?php echo e(route('list-new-requirements-received-for-production')); ?>"
                                aria-expanded="false"><i class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">New Design List</span></a>
                        </li>

                        <li class="<?php echo e(request()->is('list-accept-design*') ? 'has-arrow"' : ''); ?>">
                            <a class="has-arrow " href="<?php echo e(route('list-accept-design')); ?>" aria-expanded="false"><i
                                    class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">Accepted Design List</span></a>
                        </li>

                        <li>
                            <a class="has-arrow" href="<?php echo e(route('list-reject-design')); ?>" aria-expanded="false"><i
                                    class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">Rejected Design List</span></a>
                        </li>

                        <li>
                            <a class="has-arrow" href="<?php echo e(route('list-revised-design')); ?>" aria-expanded="false"><i
                                    class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">Revised Design List</span></a>
                        </li>

                        <li>
                            <a class="has-arrow" href="<?php echo e(route('list-material-recived')); ?>"
                                aria-expanded="false"><i class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">Material Received For Production</span></a>
                        </li>

                        
                    <?php endif; ?>
                    <?php if(session()->get('role_id') == config('constants.ROLE_ID.SECURITY')): ?>
                        <li>
                            <a class="has-arrow" href="<?php echo e(route('list-gatepass')); ?>" aria-expanded="false"><i
                                    class="fa big-icon fa-envelope icon-wrap"></i> <span class="mini-click-non">Gate
                                    Pass</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Inbox" href="<?php echo e(route('list-gatepass')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">List Gate Pass</span></a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="<?php echo e(route('list-security-remark')); ?>" aria-expanded="false"><i
                                    class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">Remark</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Inbox" href="<?php echo e(route('list-security-remark')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">List Remark</span></a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if(session()->get('role_id') == config('constants.ROLE_ID.QUALITY')): ?>
                        <li>
                            <a class="has-arrow" href="<?php echo e(route('list-grn')); ?>" aria-expanded="false"><i
                                    class="fa big-icon fa-envelope icon-wrap"></i> <span class="mini-click-non">GRN
                                    Form</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Inbox" href="<?php echo e(route('list-grn')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">List GRN</span></a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if(session()->get('role_id') == config('constants.ROLE_ID.STORE')): ?>
                        
                        <li>
                            <a class="has-arrow" href="<?php echo e(route('list-requistion')); ?>" aria-expanded="false"><i
                                    class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">Requistion</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Inbox" href="<?php echo e(route('list-requistion')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">List Requistion</span></a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="<?php echo e(route('list-store-receipt')); ?>" aria-expanded="false"><i
                                    class="fa big-icon fa-envelope icon-wrap"></i> <span class="mini-click-non">Store
                                    Receipt</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Inbox" href="<?php echo e(route('list-store-receipt')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">List Store Receipt</span></a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="<?php echo e(route('list-doc-upload-fianace')); ?>"
                                aria-expanded="false"><i class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">Document Upload to Fianace</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Inbox" href="<?php echo e(route('list-doc-upload-fianace')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">List Document Upload to Fianace</span></a></li>
                            </ul>
                        </li>


                        <li>
                            <a class="has-arrow" href="<?php echo e(route('list-accepted-design-from-prod')); ?>"
                                aria-expanded="false"><i class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">All List</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Inbox" href="<?php echo e(route('list-accepted-design-from-prod')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">List All New Requirements</span></a></li>
                                <li><a title="Inbox" href="<?php echo e(route('list-material-sent-to-prod')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">Requirements Sent To Production</span></a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if(session()->get('role_id') == config('constants.ROLE_ID.HR')): ?>
                        <li>
                            <a class="has-arrow" href="<?php echo e(route('hr-list-employees')); ?>" aria-expanded="false"><i
                                    class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">Staffs</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Inbox" href="<?php echo e(route('hr-list-employees')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">Add Staffs</span></a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                    
                    

                </ul>
            </nav>
        </div>
    </nav>
</div>
<div class="all-content-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="logo-pro">
                    <a href="index.html"><img class="main-logo" src="<?php echo e(asset('img/logo/logo.png')); ?>"
                            alt=""></a>
                </div>
            </div>
        </div>
    </div>
    <div class="header-advance-area">
        <div class="header-top-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="header-top-wraper">
                            <div class="row">
                                <div class="col-lg-1 col-md-0 col-sm-1 col-xs-12">
                                    <div class="menu-switcher-pro">
                                        <button type="button" id="sidebarCollapse"
                                            class="btn bar-button-pro header-drl-controller-btn btn-info navbar-btn">
                                            <i class="fa fa-bars"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-7 col-sm-6 col-xs-12">
                                    <div class="header-top-menu tabl-d-n">
                                        <ul class="nav navbar-nav mai-top-nav">

                                        </ul>
                                    </div>
                                </div>
                                <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
                                    <div class="header-right-info">
                                        <ul class="nav navbar-nav mai-top-nav header-right-menu">
                                            <li class="nav-item dropdown">
                                                <a href="#" data-toggle="dropdown" role="button"
                                                    aria-expanded="false" class="nav-link dropdown-toggle"><i
                                                        class="fa fa-envelope-o adminpro-chat-pro"
                                                        aria-hidden="true"></i><span class="indicator-ms"></span></a>
                                                <div role="menu"
                                                    class="author-message-top dropdown-menu animated zoomIn">
                                                    <div class="message-single-top">
                                                        <h1>Message</h1>
                                                    </div>
                                                    <ul class="message-menu">
                                                        <li>
                                                            <a href="#">
                                                                <div class="message-img">
                                                                    <img src="<?php echo e(asset('img/contact/1.jpg')); ?>"
                                                                        alt="">
                                                                </div>
                                                                <div class="message-content">
                                                                    <span class="message-date">16 Sept</span>
                                                                    <h2>Advanda Cro</h2>
                                                                    <p>Please done this project as soon possible.</p>
                                                                </div>
                                                            </a>
                                                        </li>

                                                    </ul>
                                                    <div class="message-view">
                                                        <a href="#">View All Messages</a>
                                                    </div>
                                                </div>
                                            </li>
                                            <li class="nav-item"><a href="#" data-toggle="dropdown"
                                                    role="button" aria-expanded="false"
                                                    class="nav-link dropdown-toggle"><i class="fa fa-bell-o"
                                                        aria-hidden="true"></i><span class="indicator-nt"></span></a>
                                                <div role="menu"
                                                    class="notification-author dropdown-menu animated zoomIn">
                                                    <div class="notification-single-top">
                                                        <h1>Notifications</h1>
                                                    </div>
                                                    <ul class="notification-menu">
                                                        <li>
                                                            <a href="#">
                                                                <div class="notification-icon">
                                                                    <i class="fa fa-check adminpro-checked-pro admin-check-pro"
                                                                        aria-hidden="true"></i>
                                                                </div>
                                                                <div class="notification-content">
                                                                    <span class="notification-date">16 Sept</span>
                                                                    <h2>Advanda Cro</h2>
                                                                    <p>Please done this project as soon possible.</p>
                                                                </div>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                    <div class="notification-view">
                                                        <a href="#">View All Notification</a>
                                                    </div>
                                                </div>
                                            </li>
                                            <li class="nav-item">
                                                <a href="#" data-toggle="dropdown" role="button"
                                                    aria-expanded="false" class="nav-link dropdown-toggle">
                                                    <i class="fa fa-user adminpro-user-rounded header-riht-inf"
                                                        aria-hidden="true"></i>
                                                    <span class="admin-name">Advanda Cro</span>
                                                    <i class="fa fa-angle-down adminpro-icon adminpro-down-arrow"></i>
                                                </a>
                                                <ul role="menu"
                                                    class="dropdown-header-top author-log dropdown-menu animated zoomIn">

                                                    <li><a href="<?php echo e(route('log-out')); ?>"><span
                                                                class="fa fa-lock author-log-ic"></span>Log Out</a>
                                                    </li>
                                                </ul>
                                            </li>

                                        </ul>

                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php /**PATH C:\xampp\htdocs\shreerang-main_bk\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>