
<?php $__env->startSection('content'); ?>
<style>
    label {
        margin-top: 20px;
    }
</style>
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="sparkline12-list">
            <div class="sparkline12-hd">
                <div class="main-sparkline12-hd">
                    <center><h1>Add Organization Data</h1></center>
                </div>
            </div>
            <div class="sparkline12-graph">
                <div class="basic-login-form-ad">
                    <div class="row">
                        <?php if(session('msg')): ?>
                            <div class="alert alert-<?php echo e(session('status')); ?>">
                                <?php echo e(session('msg')); ?>

                            </div>
                        <?php endif; ?>

                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                             <?php if(Session::get('status') == 'success'): ?>
                                <div class="col-12 grid-margin">
                                    <div class="alert alert-custom-success " id="success-alert">
                                        <button type="button"  data-bs-dismiss="alert"></button>
                                        <strong style="color: green;">Success!</strong> <?php echo e(Session::get('msg')); ?>

                                    </div>
                                </div>
                            <?php endif; ?>

                            <?php if(Session::get('status') == 'error'): ?>
                                <div class="col-12 grid-margin">
                                    <div class="alert alert-custom-danger " id="error-alert">
                                        <button type="button"  data-bs-dismiss="alert"></button>
                                        <strong style="color: red;">Error!</strong> <?php echo session('msg'); ?>

                                    </div>
                                </div>
                            <?php endif; ?>

                            
                            <div class="all-form-element-inner">
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <form action="<?php echo e(route('update-organizations')); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group-inner">
                                                <input type="hidden" class="form-control" value="<?php if(old('id')): ?> <?php echo e(old('id')); ?><?php else: ?><?php echo e($editData->id); ?> <?php endif; ?>" id="id" name="id" >
                                        <div class="row">
                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                <label for="company_name">Company Name:</label>
                                                <input type="text" class="form-control" value="<?php if(old('company_name')): ?> <?php echo e(old('company_name')); ?><?php else: ?><?php echo e($editData->company_name); ?> <?php endif; ?>" id="company_name" name="company_name" placeholder="Enter company name">
                                            </div>
                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                <label for="email">Email:</label>
                                                <input type="email" class="form-control" id="email" value="<?php if(old('email')): ?> <?php echo e(old('email')); ?><?php else: ?><?php echo e($editData->email); ?> <?php endif; ?>" name="email" placeholder="Enter email">
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                <label for="mobile_number">Mobile Number:</label>
                                                <input type="text" class="form-control" id="mobile_number" value="<?php if(old('mobile_number')): ?> <?php echo e(old('mobile_number')); ?><?php else: ?><?php echo e($editData->mobile_number); ?> <?php endif; ?>" name="mobile_number" placeholder="Enter mobile number">
                                            </div>
                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                <label for="address">Company Address:</label>
                                                <input type="text" class="form-control" id="address" value="<?php if(old('address')): ?> <?php echo e(old('address')); ?><?php else: ?><?php echo e($editData->address); ?> <?php endif; ?>" name="address" placeholder="Enter company address">
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                <label for="employee_count">Employee Count:</label>
                                                <input type="text" class="form-control" id="employee_count" value="<?php if(old('employee_count')): ?> <?php echo e(old('employee_count')); ?><?php else: ?><?php echo e($editData->employee_count); ?> <?php endif; ?>" name="employee_count" placeholder="Enter employee count">
                                            </div>
                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                <label for="founding_date">Foundation Date:</label>
                                                <input type="text" class="form-control flatpickr-input" id="founding_date" value="<?php if(old('founding_date')): ?> <?php echo e(old('founding_date')); ?><?php else: ?><?php echo e($editData->founding_date); ?> <?php endif; ?>" name="founding_date" placeholder="Enter foundation date">
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                <label for="facebook_link">Facebook Link:</label>
                                                <input type="text" class="form-control" id="facebook_link" value="<?php if(old('facebook_link')): ?> <?php echo e(old('facebook_link')); ?><?php else: ?><?php echo e($editData->facebook_link); ?> <?php endif; ?>" name="facebook_link" placeholder="Enter Facebook link">
                                            </div>
                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                <label for="instagram_link">Instagram Link:</label>
                                                <input type="text" class="form-control" id="instagram_link" value="<?php if(old('instagram_link')): ?> <?php echo e(old('instagram_link')); ?><?php else: ?><?php echo e($editData->instagram_link); ?> <?php endif; ?>" name="instagram_link" placeholder="Enter Instagram link">
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                <label for="twitter_link">Twitter Link:</label>
                                                <input type="text" class="form-control" id="twitter_link" value="<?php if(old('twitter_link')): ?> <?php echo e(old('twitter_link')); ?><?php else: ?><?php echo e($editData->twitter_link); ?> <?php endif; ?>" name="twitter_link" placeholder="Enter Twitter link">
                                            </div>
                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                <label for="website_link">Website Link:</label>
                                                <input type="text" class="form-control" id="website_link" value="<?php if(old('website')): ?> <?php echo e(old('website')); ?><?php else: ?><?php echo e($editData->website); ?> <?php endif; ?>" name="website_link" placeholder="Enter website link">
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                <label for="image">Image:</label>
                                                <input type="file" class="form-control" id="image" name="image" value="<?php if(old('image')): ?> <?php echo e(old('image')); ?><?php else: ?><?php echo e($editData->image); ?> <?php endif; ?>">
                                                <?php if(old('image') || isset($editData)): ?>
                                                    <div>
                                                        <label>Old Image:  </label>
                                                        <img src="<?php if(old('image')): ?> <?php echo e(old('image')); ?> <?php elseif(isset($editData)): ?> <?php echo e(Config::get('DocumentConstant.ORGANIZATION_VIEW') . $editData->image); ?> <?php endif; ?>" alt="Old Image" style="max-width: 100px;">
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                    <div class="sparkline12-graph">
                                                        <div id="pwd-container1">
                                                            <div class="form-group">
                                                                <label for="password1">Password</label>
                                                                <input type="password" class="form-control example1" name="password" id="password1" placeholder="Password" value="Passwo">
                                                            </div>
                                                            <div class="form-group">
                                                                <div class="pwstrength_viewport_progress"></span></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                            </div>
                                        </div>  
                                        </div>


                                        <div class="login-btn-inner">
                                            <div class="row">
                                                <div class="col-lg-5"></div>
                                                <div class="col-lg-7">
                                                    <div class="login-horizental cancel-wp pull-left">
                                                        <a href="<?php echo e(route('list-organizations')); ?>"><button class="btn btn-white" style="margin-bottom:50px">Cancel</button></a>
                                                        <button class="btn btn-sm btn-primary login-submit-cs" type="submit" style="margin-bottom:50px">Save Data</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    flatpickr(".flatpickr-input", {
        dateFormat: "d/m/Y",
        allowInput: true
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shreerag_final_updated\resources\views/admin/pages/organizations/edit-organizations.blade.php ENDPATH**/ ?>